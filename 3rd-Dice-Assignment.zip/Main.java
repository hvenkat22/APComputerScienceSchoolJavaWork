//Grader's Name: 
//Score on 100,000 Craps: 
// Venkataraman_DiceAssignment
// Hari Venkataraman
// 3rd Assignment: Dice Assignment
//Regrader: Karis Liu
// Regraded Score 1/0 (+1 bonus point)

class Main {
  static KeyboardReader reader = new KeyboardReader();
  public static void main(String[] args) {
    while(true){
     int answer = reader.readInt("Enter 1 to run the 1st assignment, 2 to run the 2nd assignment, 3 to run the game of Craps, 4 to run the 100,000 craps simulation or 0 to exit the program: "); 
     System.out.println("\n");
    
      if(answer == 1){
        diceAssignment1();
        System.out.println("\n");
        continue;//Looping menu to run the methods
      } else if(answer == 2){
        diceAssignment2();
        System.out.println("\n");
        continue;//This contiinue is here to loop back to beginning after done with running code
      } else if(answer == 3){
        gameOfCraps();
        System.out.println("\n");
        continue;
      } else if(answer == 4){
        crapsProbability();
        System.out.println("\n");
        continue;
      } else if(answer == 0){
        break;//Exiting
      } else{
        System.out.println("You've entered a number out of the given range.");
        continue;
      }
    }
    
    
     
     
  }
  public static void diceAssignment1(){
    int count = 0;
    Dice side = new Dice(6);
    Dice dice2 = new Dice(6);//Declares 2 six-sided dies
    while(true){//MCKEEN:I LIKE YOUR while(true)
      int response = reader.readInt("How many times would you like to roll the dice? ");
    for(int i=0; i<response; i++){
      int rolls = side.roll();
      int rolls2 = dice2.roll();//Rolls for how many times the user enters
      int sumOfRolls = rolls + rolls2;//Sum of the two rolls 
      count++;
       System.out.println("Roll #" + count + ":" + "  " + rolls + " + " + rolls2 + " = " + sumOfRolls);//Prints results 
       reader.pause();
    }
    String playAgain = reader.readLine("Would you like to play again?(Y/N) ");//Allows player to run more without exiting
    //MCKEEN: I LIKE THIS .EQUALSIGNORECASE METHOD BUT I THINK YOUR CODE WOULD STILL BE SIMPLER WITH A char.
    if(playAgain.equalsIgnoreCase("Y")){
      count = 0;//Resets count so count won't be added
      continue;
    } else if(playAgain.equalsIgnoreCase("N")){
      System.out.println("Thanks for playing!!");
      break;//Exits back to the beginning
    }
    }
    
  }
  public static void diceAssignment2(){
    
     Dice third = new Dice(6);
     int[] diceArray = new int[6];//Possible outcomes of a die stored in array (1,2,3,4,5,6)
     int j = 0;
     //MCKEEN:GOOD CHOICE OF AN IF ELSE IF LADDER INSTEAD OF A SERIES OF IFS!
     for(int i=0; i<10000; i++){
       j = third.roll();//Rolls 10,00 times
       if(j == 1){
         diceArray[0] ++;
       } else if(j == 2){
         diceArray[1]++;//if else if ladder to sort between how many of each of the outcomes were encountered
       } else if(j == 3){
         diceArray[2]++;
       } else if(j == 4){
         diceArray[3]++;
       } else if(j == 5){
         diceArray[4]++;
       } else if(j == 6){
         diceArray[5]++;//Incrementations add up at the end
       }
     }
     //MCKEEN:YAY!  A FOR LOOP INSTEAD OF 6 SOPs
     for(int i=0; i<diceArray.length; i++){
      System.out.println("Number of times " + 
      (i+1) +  " was rolled:  " + diceArray[i]);//Prints the results instead of 6 print lines 
     }
     
     
  }
public static void gameOfCraps(){
  int point = 0;
  while(true) {
    Dice firstDie = new Dice(6);//Declares two six-sided dies
    Dice secondDie = new Dice(6);
    int rollOne = firstDie.roll();
    int rollTwo = secondDie.roll();
    int addition = rollOne + rollTwo;
    System.out.println("Player rolled a   " + rollOne + " + " + rollTwo + " = " + addition);//Displays the addition within the while loop so it will be easier to continue and break
    point = addition;//Useful for the point make in Craps
   
    if(addition == 7 || addition == 11){
      System.out.println("Player Wins!");//Prints out player wins if addition is either 7 or 11
      
    } else if(addition == 2 || addition == 3 || addition == 12){
      System.out.println("Player loses.");//Player loses if any of the conditions are met
      
    } else {   
      System.out.println("Point is: " + point);
      while(true) { //This while is here because since 7 in the previous loops is to win and after the player continues with the point, the 7 has to be stored in a different variable  
      int rollThree = firstDie.roll();
      int rollFour = secondDie.roll();
      int addition2 = rollThree + rollFour;
      System.out.println("Player rolled a " + rollThree + " + " + rollFour + " = " + addition2);//Repeat for the continutation
      if(addition2 == point){
        System.out.println("Player wins." + "\n");//Player wins if player rolls a point again
        break;
      } else if(addition2 == 7){
        System.out.println("Player loses." + "\n");//Player loses when they roll a sum of 7 in the continuation
        break;
      }
     //MCKEEN:A WHILE LOOP WITH TWO BREAKS IS GOOD.  DO YOU KNOW HOW YOU WOULD WRITE THE CONDITION THAT GOES NEXT TO THE while?  IT MIGHT BE ON A TEST SOON...
     }
    }
   String playAgain = reader.readLine("Would you like to play again?(Y/N)  ");
   if(playAgain.equalsIgnoreCase("Y")){
     continue;//To continue playing
   } else {
     System.out.println("Thank you for playing.");//Exits with a thank you message
     break;
   }
  }
   
   }
   public static void crapsProbability(){
      Dice d1 = new Dice(6);
      Dice d2 = new Dice(6);//Creates 2 six-sided Dice objects
      int roll1 = 0, roll2 = 0, point = 0, sum = 0;
      int firstRollWin = 0, firstRollLoss = 0, pointWin = 0, pointLoss = 0;//Declares and initializes all variables involved in Craps
      for(int i=0; i<100000; i++){
         roll1 = d1.roll();
         roll2 = d2.roll();
         sum = roll1 + roll2;
         if(sum == 7 || sum == 11){
           firstRollWin++;//Winning on first roll
         } else if(sum == 2 || sum == 3 || sum == 12){
           firstRollLoss++;//Losing on first roll
         } else{
           point = sum;//The point is for all other outputs for the first roll
           while(true){
             roll1 = d1.roll();
             roll2 = d2.roll();
             sum = roll1 + roll2;//Repeats process for point
             if(sum == point){
               pointWin++;//Winning after output of point
               break;
             } else if(sum == 7){
               pointLoss++;//Losing after output of 7
               break;
             }
           }
         }
      }
      //Displaying the probabilities.
      System.out.println("The game of Craps has been played 100,000 times.");
      System.out.println("Probabilitiy of: " + "\nWinning: " + (firstRollWin + pointWin)/100000.0 + "\nLosing: " + (firstRollLoss + pointLoss)/100000.0 + "\nWinning on the first roll: " + firstRollWin/100000.0 + "\nWinning by making Point: " + pointWin/100000.0 + "\nLosing on the first roll: " + firstRollLoss/100000.0 + "\nLosing by making Point: " + pointLoss/100000.0);

   }
   
  }

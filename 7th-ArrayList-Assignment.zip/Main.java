//Hari Venkataraman
//ArrayList.java
//ArrayList Assignment
import java.util.ArrayList;
public class Main{
   static boolean a;
   public static void main(String[] args){
      KeyboardReader reader = new KeyboardReader();
      ArrayList<Fraction> list = new ArrayList<Fraction>();
      System.out.println("\nWelcome to the ArrayList Program!!");
      while(true){
         int ans = reader.readInt("\nMenu: " + "\n\t1. Display the list of fractions." + "\n\t2. Add a fraction to the end of the list." + "\n\t3. Insert a fraction at a specific location." + "\n\t4. Remove a fraction from a specific location." + "\n\t5. Remove a fraction by value." + "\n\t6. Replace a fraction at a specific location." + "\n\t7. Display the list from smallest to largest." +"\n\t0. Exit the Program:   ");//Displays Menu to the screen for user to choose from.
         if(ans == 1){
           int count = 0;
           if(list.size() == 0){
             System.out.println("\nThe list is empty. Please add Fractions to the list to be displayed.");//If the list is empty, then the user has to enter values by selecting other options from the menu.
           } else {
              System.out.println("\nThe list currently contains:");
              for(int i=0; i<list.size(); i++){
                count++;
                System.out.println("\n\t" + count + "." + "    " + list.get(i));//Displays the list accordingly
              }
           }
           reader.pause();//pause in between.
           continue;
         } else if(ans == 2){
            int num = reader.readInt("\nEnter the numerator of Fraction: ");//Reads in numerator
            int denom = reader.readInt("\nEnter the denominator of the Fraction: ");//Reads in denominator.
            Fraction frac = new Fraction(num,denom);//Creates a new fraction with the numerator and denominator that is read.
            list.add(frac);//Adds the fractions to the list to be printed in option 1.
            System.out.println("\nThe fraction has been added to the end of the list.");
            reader.pause();
            continue;
         } else if(ans == 3){
             System.out.println("\nEnter the numerator and the denominator of a fraction that you would like to a specific position in the list or at the end of the list.\n");
             int numer = reader.readInt("Enter the numerator of the Fraction: ");
             int denomi = reader.readInt("\nEnter the denominator of the Fraction: ");//Same thing repeated reading.
             Fraction fractal = new Fraction(numer, denomi);
             int pos = reader.readInt("Which position would you like to add this Fraction into the list? ");//Reads in position in which the user will add into the list.
             if(list.size() < pos-1){
               System.out.println("Error: Please enter a valid position.");
               list.remove(fractal);//If the position is out of bounds, then there's an error message.
             } else {
                 list.add(pos-1, fractal);//Adds the fraction to the list if the position is valid.
                 System.out.println("\nThe Fraction has been added to the list.");
             }
             reader.pause();
             continue;
         } else if(ans == 4){
             int result = reader.readInt("\nEnter the position in which you would like to remove a fraction: ");
             if(result < 0){
               System.out.println("Please enter a location greater than 0.");
               continue;
             }
             if(list.size() < result){
               System.out.println("\nPlease enter a vaid position.");
             } else {
               list.remove(result-1);
               System.out.println("\nThe Fraction has been removed.");
             }
             reader.pause();
             continue;
         } else if(ans == 5){
             int numera = reader.readInt("\nEnter the numerator of the fraction you would like to remove:  ");
             int denomin = reader.readInt("\nEnter the numerator of the fraction you would like to remove: ");
             Fraction f1 = new Fraction(numera, denomin);
             for(int i=0; i<list.size(); i++){
               if(f1.equals(list.get(i))){
                 list.remove(i);
                 a = true;
                 break;
               }
             }
             if(a==true){
                 System.out.println("The fraction " +f1 + " has been removed from the list.");
               } else if(a==false){
                 System.out.println("That fraction was not in the list");
               }

             reader.pause();
             continue; 
             }
          else if(ans == 6){
            int numerat = reader.readInt("Enter the numerator for the fraction to replace: ");
            int denominat = reader.readInt("Enter the denominator for the fraction to replace: ");
            Fraction frac2 = new Fraction(numerat, denominat);
            int pos2 = reader.readInt("Enter the location at which this fraction is to replace the existing fraction: ");
            if(list.size() < pos2){
              System.out.println("Error: There is no fraction in the list at that location.");
            } else {
              list.set(pos2-1, frac2);
              System.out.println("The Fraction has been successfully replaced.");
            }
            reader.pause();
            continue;
         } else if(ans == 7){
             for(int i=0; i<list.size(); i++){ 
               for (int j =0; j<list.size(); j++){
                 double x = list.get(i).toDouble();
                 double y = list.get(j).toDouble();
                 if(y > x){
                   Fraction temp = list.get(i);
                   Fraction temp2 = list.get(j);
                   list.set(j,temp);
                   list.set(i,temp2);
                 } 
               }
               
             }
             
             for(int i=0; i<list.size(); i++){
               System.out.print(list.get(i) + ", ");
             }
         } else if(ans == 0){
             System.out.println("Have a nice day! Thank you!");
             break;
         } else {
           System.out.println("Please enter a number in the given range.");
           continue;
         }
  }
}
}


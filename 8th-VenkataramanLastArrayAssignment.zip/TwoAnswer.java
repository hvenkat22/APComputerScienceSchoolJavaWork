public class TwoAnswer {

	private int answer1;
	private int answer2;

	public TwoAnswer(int a1, int a2) {
		answer1 = a1;
		answer2 = a2;
	}

	public int getanswer1() {
		return answer1;
	}

	public int getanswer2() {
		return answer2;
	}

}
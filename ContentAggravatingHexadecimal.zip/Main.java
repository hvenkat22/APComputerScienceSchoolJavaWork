// VehicleRunner
// McKeen
// Testing the Vehicle Class 

//This runner uses KeyboardReader

public class Main
{
	public static void main(String[] args)
	{
		KeyboardReader reader = new KeyboardReader();
		
		//CREATE A NEW VEHICLE and DO STUFF WITH IT
    System.out.println("\n\nINSIDE VEHICLE RUNNER:\n");
    Vehicle bicycle = new Vehicle();
    bicycle.displayInfo();
				
	}
}

// Please work on these problems with your teammates
// When you ALL have them working properly, please
// then work together on the MC questions in AP Classroom

class Main {
  public static void main(String[] args) {

    KeyboardReader reader = new KeyboardReader();

    String[] names = {"Rita", "Himank", "Ben", "Max", "Yubin", "Alex",
    "Alex", "Minji", "Tamar", "Sneha", "Rohan", "Andrew", "Vincent", "Pranav", 
    "Grace", "Joy", "Joy", "Joy", "Zach", "Hugh", "Trevor", "Angel", "Nick", "Nick"};

    int[][] values = {{1,2,3,4,5,6}, {7,8,9,10,11,12}, {13,14,15,16,17,18}, {19,20,21,22,23,69}};

    // ASSIGNMENT 1
    // In the space below, use an Enhanced For Loop to do the following:
    // a. read in a name from the keyboard
    // b. count and display the total number of times that name is found in the array called names
     int count = 0;
     String name  =  reader.readLine("Enter a name: ");
     for(String val: names){
       if(val.equals(name)){
         count++;
       }
     }
     System.out.println("That name was found "  + count + " times in the array.");
    // ASSIGNMENT 2
    // In the space below, use an Enhanced For Loop to do the following:
    // a. Attractively display all of the values in the array called values
    //    The display should look like a matrix

    for(int[] row: values){
      for(int val: row){
        System.out.print(val + "\t");
      }
      System.out.println();
    }

    // ASSIGNMENT 3
    // When you are done, continue working with your team to complete the 4 Multiple Choice questions found in AP Classroom 
   }
}
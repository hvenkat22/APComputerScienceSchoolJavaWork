import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintWriter;

public class Main {
  public static void main(String[] args) throws FileNotFoundException{
   Scanner s = new Scanner(System.in);
   System.out.println("\n Welcome to the madLib program!");
   generateMadlib();
  }
  public static void generateMadlib() throws FileNotFoundException{
    KeyboardReader console = new KeyboardReader();
    File f1 = new File("Madlib.txt");
    Scanner input = new Scanner(f1);
    String output = "";
    while(input.hasNextLine()){
      String line = input.next();
      int idx1 = line.indexOf('[');
      int idx2 = line.indexOf(']');
      if(idx1 >= 0 && idx2 > 0){
        char first = line.charAt(1);
        String article2 = handleVowel(first);
        line = line.replace("[", " "); 
        line = line.replace("]"," ");
        line = line.replace("_"," ");
        System.out.println("\nPlease type " + article2 + line);
        String newText = console.readLine();
        output += newText + " ";
      } else {
        output += line + " ";
      }
    }
    System.out.println(output);
    File outputFile = new File("MadlibOutput.txt");
    PrintWriter writer = new PrintWriter(outputFile);
    writer.println(output);
    input.close();
    writer.close();
  }
  public static String handleVowel(char check){
    String article;
    if(check == 'a' || check == 'A' || check ==  'e' || check == 'E' || check == 'i' || check == 'I' || check == 'o' || check == 'O' || check == 'u' || check == 'U'){
      article = "an";
    } else {
      article = "a";
    }
    return article;
  }
}
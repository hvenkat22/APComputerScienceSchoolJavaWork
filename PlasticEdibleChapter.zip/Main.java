//McKeen 
//PolygonsRunner.java 
//An introduction to inheritance in OOP

public class Main
{
	public static void main(String[]args)
	{
		KeyboardReader reader = new KeyboardReader();

// Let's add a polygon here


	}	
}

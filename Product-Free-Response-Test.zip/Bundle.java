import java.util.ArrayList;
public class Bundle implements Product {
    private ArrayList<Product> bundle;
    public Bundle() {
       bundle = new ArrayList<Product>();
    }
    public void add(Product product2) {
       bundle.add(product2);
   }
   public double getPrice(){
      double sum = 0;
      for(int i=0; i<bundle.size(); i++){
         sum+=bundle.get(i).getPrice();
      }
      return sum;
   }
}
  

public class Pack implements Product{
    private Product p1;
    private int quantity;
    public Pack(int numOccur, Product product){
        p1 = product;
        quantity = numOccur; 
    }
    public double getPrice(){
         return p1.getPrice()*quantity;
    }
}
     

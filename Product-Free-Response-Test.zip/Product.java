public interface Product{
  double getPrice();
}
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.HashMap;
class Main {
  public static void main(String[] args) {
    int[] numbers = {10,20,30,40,50,60};
    Set hSet = new HashSet();
    for(int k=0; k<numbers.length; k++){
      hSet.add(new Integer(numbers[k]));
    }
    Iterator iter = hSet.iterator();
    for(int k=0; k<hSet.size(); k++){
      iter.next();
      iter.remove();
    }
    System.out.println(hSet);
    Map map1 = new HashMap();
Map map2 = new TreeMap();
map1.put("A", "Aardvark");
map1.put("B", "Bear");
map1.put("C", "Cat");
map1.put("D", "Dog");
map2.put("A", "Aardvark");
map2.put("B", "Bear");
map2.put("C", "Cat");
map2.put("D", "Dog");
System.out. println(map1);
System.out. println(map2);
System.out.println(quest0902(2,3));
System.out.println(quest0904(2,3));
System.out.println(quest0906(4,3));
System.out.println(quest0908a(74,111));
quest0910(5);
System.out.println(quest0913(4));
quest0914("TANGO");
  }
  public static int quest0902(int a, int b)
// precondition: a > 0 and b > 0
{
	if(b == 1)
		return a;
	else 
		return a * quest0902(a, b-1);
}
public static int quest0904(int a, int b)
// precondition: a > 0 and b > 0
{
	if (a == 1)
		return b;
	else
		return b * quest0904(a-1,b);
}
public static int quest0906(int x, int y)
{
	if (x < y)
		return x;
	else
		return y + quest0906(x-1,y+1);
}

public static int quest0908a(int x, int y)
{
	return x / quest0908b(x,y) * y;
}

public static int quest0908b(int x, int y)
{
	if (x % y == 0)
		return y;
	else
		return quest0908b(y,x%y);
}
public static void quest0910(int n)
{
	if (n >= 0)
		quest0910(n-1);
	System.out.println(n + " ");
}
public static int quest0913(int q)
{
	if (q == 1)
		return 1;
	else 
		return q + quest0913(q-1) + quest0913(q-1);
}
public static void quest0914(String s)
{
	int n = s.length();
	if(n > 1)
	{
		String temp = s.substring(0, n-1);
		System.out.println(temp);
		quest0914(temp);
	}
}





}
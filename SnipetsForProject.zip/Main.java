public class InformationHidingEx{
  private int x;
  
  public InformationHidingEx(int x1){
    x=x1;
  }
  public int getX(){
    return x;
  }
}
class Main {

  public static void printTwo(animal one, animal two){
    System.out.println(one.getName() + " " + two.getName());
  }


  public static void main(String[] args) {

    animal a1 = new animal("dog");
    animal a2 = new animal(null);
    animal a3;

    printTwo(a1,a1);
    printTwo(a1,a2);
    printTwo(a2,a2);
    printTwo(a1,a3);

  }
}

class animal{
  private String name;

  public animal(String n){
    name = n;
  }
  public String getName(){
    return name;


class Pet{

  String talk = "hello!";

}

fraction x;
fraction x.add(3,4);

class Kangaroo extends Pet{

  String talk = "hey";

  public void speak(){

    System.out.println(super.talk);

  }

  class Utensil{

  int Prongs;
  boolean isSpoon;

  Utensil(){
    System.out.println("I am a utensil!");
  }

}

class Spork extends Utensil{

  Spork(){
    super();
    System.out.println("I am a spork!");

    Prongs = 3;
    isSpoon = true;
    System.out.println(Prongs);
  }




  }
}

public class Rectangle {

	public void talk() {
		System.out.println("I'm a rectangle");
	}

}

public class Square extends Rectangle {

	public void talk() {
		super.talk();
		System.out.println("I am also a square");
	}

}

/*Square a = new Square();
a.talk();

Reactangle b = new Square();
b.talk();

Square c = new Square();
c.super.talk();

Rectangle d = new Rectangle();
d.talk();*/
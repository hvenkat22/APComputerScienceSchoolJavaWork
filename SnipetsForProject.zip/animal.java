public class animal{

	private String name;

	public animal(String n){
		name = n;
	}
	public void changeName(String newName){
		name = newName;
	}

}
import java.util.LinkedList;

// YOUR NAME
// StackList.java
// Write your own Stack using a LinkedList as the private variable

public class StackList<E>
{ 
  private LinkedList<E> list;
  public StackList(){
    list = new LinkedList<E>();//Initialize Instance variable.
  }
  public void push(E element){
    list.addFirst(element);//Pushes it onto the Stack.
  }
  public E pop(){
    return list.removeFirst();//Pops or removes from top of Stack.
  }
  public E peek(){
    return list.getFirst();//Returns the topmost value in the Stack.
  }
  public boolean isEmpty(){
    return list.size() == 0;//Boolean to check if StackList is empty.
  }  
}

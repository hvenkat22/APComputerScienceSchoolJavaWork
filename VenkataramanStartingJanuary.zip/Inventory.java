import java.util.ArrayList;

public class Inventory
{
   private ArrayList<Product> allProducts;

   public Inventory()
   { 
   	 	allProducts = new ArrayList<Product>();
   }

   public void addNewProduct(String name, int amount)
   {
      /* to be implemented in part (a) */
   
   }	

   public ArrayList<String> mustOrder()
   {
      /* to be implemented in part (b) */

      //DELETE THIS LINE:
      return null;
   }

   public void displayProducts()
   {
      /* code that displays all products */
      for(Product p: allProducts)
      	System.out.println(p.getItemName() + " - " + p.getQuantity());
   }
}
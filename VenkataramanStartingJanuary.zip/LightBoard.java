public class LightBoard
{
   /* The lights on the board, where true represents on and false represents off. */
  	private boolean[][] lights;

  	// DO NOT CHANGE THIS METHOD
    // This constructor initializes the array to false
  	public LightBoard(int numRows, int numCols)
  	{
  		lights = new boolean[numRows][numCols];
  		// There could be more code here to initialize the booleans
  	}
  	
  	// DO NOT CHANGE THIS METHOD
    // This constructor copies the values in the parameter
  	public LightBoard(boolean[][] copyMe)
  	{
  		lights = new boolean[copyMe.length][copyMe[0].length];
  		for(int i = 0; i< copyMe.length; i++)
  			for(int j = 0; j<copyMe[0].length; j++)
  				lights[i][j] = copyMe[i][j];
  	}
  	
  	/* Counts and returns the number of lights that are on.
     Precondition: the two-dimensional array of lights has been initialized. 
  	*/
  	public int countLightsOn()
  	{ /* to be implemented in part (a) */ 
  		
      //DELETE THIS LINE:
      return -1;		
 
  		
  	}

  	/* Evaluates a light in row index row and column index col and returns a status as described in part (b). 
    Precondition: row and col are valid indexes in lights and the two-dimensional array of lights has been initialized. 
  	*/
  	public boolean evaluateLight(int row, int col)
  	{  /* to be implemented in part (b) */ 
  		
      //DELETE THIS LINE:
      return true;
    }
}

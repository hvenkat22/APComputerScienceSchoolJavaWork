
/*
Hello super-smart APCS students!

Try right-clicking on the file name to Add Tab.  HELPFUL!

This runner file contains test cases for your FRQs.
The correct screen display is listed at in the comments at the bottom of the document.

Please do the following:
1. Copy your FRQ solutions from Edulastic into the Inventory.java and  LightBoard.java files in this repl
2. Fix them so that they pass the test cases.
3. Help your teammates
4. What you do not complete is homework for tomorrow.

*/

import java.util.ArrayList;

public class Main 
{
    public static void main(String[] args) 
    {
		//// TESTING THE INVENTORY AND PRODUCT CLASSES
		Inventory hardware = new Inventory();
		
		// add to empty list and display
		System.out.println("\nAfter adding to an empty list:");
		hardware.addNewProduct("hammer", 100);
		hardware.displayProducts();		
		
		// add to the end and display
		System.out.println("\nAfter adding to the end:");
		hardware.addNewProduct("saw", 15);
		hardware.displayProducts();		
		
		// add to the beginning and display
		System.out.println("\nAfter adding to the beginning:");
		hardware.addNewProduct("drill", 25);
		hardware.displayProducts();

		// add to the end and display
		System.out.println("\nAfter adding to the end of a 3 element list:");
		hardware.addNewProduct("vise", 10);
		hardware.displayProducts();
		
		// display items to order	
		System.out.println("\nDisplay the items with quantity less than 20:");
		ArrayList<String> order = hardware.mustOrder();
		System.out.println(order);	
			
		// Add many items and display
		System.out.println("\nAfter adding many more items to the list:");																							
		hardware.addNewProduct("anvil", 15);
		hardware.addNewProduct("washers", 1000);
		hardware.addNewProduct("screwdriver", 100);
		hardware.addNewProduct("wrench", 15);
		hardware.addNewProduct("wheelbarrow", 15);
		hardware.addNewProduct("flashlight", 150);
		hardware.displayProducts();

		//// TESTING THE LIGHTBOARD CLASS
		
  		boolean[][] lightValues = {{true,true,false,true,true},
  					{true,false,false,true,false},
  					{true,false,false,true,true},
  					{true,false,false,false,true},
  					{true,false,false,false,true},
  					{true,true,true,true,true},
  					{false,false,false,false,false} }; 
  						
  		LightBoard sim = new LightBoard(lightValues);
   		System.out.print("\n Counting the number of lights on: ");
  		System.out.println(sim.countLightsOn());
  		
 		
   		System.out.println("\nEvaluating light when it is the only one on in its column: ");
  		System.out.println(sim.evaluateLight(5,2));

   		System.out.println("\nEvaluating light when it is off but all others in its column are on: ");
  		System.out.println(sim.evaluateLight(6,0));
 
   		System.out.println("\nEvaluating light when it is on and so are others in its column: ");
  		System.out.println(sim.evaluateLight(5,4));
  		
   		System.out.println("\nAssorted test cases: ");
  		System.out.println(sim.evaluateLight(4,1));
   		System.out.println(sim.evaluateLight(0,0));
   		System.out.println(sim.evaluateLight(6,4));
   		System.out.println(sim.evaluateLight(0,1));
		
		
	}
}


/*
CORRECT OUTPUT FOR Inventory

After adding to an empty list:
hammer - 100

After adding to the end:
hammer - 100
saw - 15

After adding to the beginning:
drill - 25
hammer - 100
saw - 15


After adding to the end of a 3 element list:
drill - 25
hammer - 100
saw - 15
vise - 10

Display the items with quantity less than 20:
[saw, vise]

After adding many more items to the list:
anvil - 15
drill - 25
flashlight - 150
hammer - 100
saw - 15
screwdriver - 100
vise - 10
washers - 1000
wheelbarrow - 15
wrench - 15


 CORRECT OUTPUT for LightBoard:
 
 Counting the number of lights on: 18
 
 Evaluating light when it is the only one on in its column: 
 false
 
 Evaluating light when it is off but all others in its column are on: 
 false
 
 Evaluating light when it is on and so are others in its column: 
 true
 
 Assorted test cases:
 false
 true
 false
 true
 
 */	
	

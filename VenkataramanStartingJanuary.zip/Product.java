class Product
{
   private String itemName;   // all item names will be in lowercase
   private int quantity;

   public Product (String i, int q)
      { 
      	itemName = i;
      	quantity = q;
      }

   public String getItemName() 
   {
      return itemName;
   }
   public int getQuantity() 
   {
      return quantity;
   }
}

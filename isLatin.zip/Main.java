class Main {
  public static void main(String[] args) {
    int[][] test = {{1,2,3},{2,3,1},{3,1,2}};
    int[] sub = test[0];
    for(int r=0; r<sub.length; r++){
      System.out.println(sub[r]);
    }
  }
  
}